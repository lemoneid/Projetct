/*************************************************************************
	> File Name: send_chat.h
	> Author: yanzhiwei
	> Mail: 1931248856@qq.com
	> Created Time: 2021年03月25日 星期四 20时03分07秒
 ************************************************************************/

#ifndef _SEND_CHAT_H
#define _SEND_CHAT_H
void send_chat();
#endif
