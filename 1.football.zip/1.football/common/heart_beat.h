/*************************************************************************
	> File Name: heart_beat.h
	> Author: yanzhiwei
	> Mail: 1931248856@qq.com
	> Created Time: 2021年03月25日 星期四 14时26分18秒
 ************************************************************************/

#ifndef _HEART_BEAT_H
#define _HEART_BEAT_H
void *heart_beat(void *arg);
#endif
