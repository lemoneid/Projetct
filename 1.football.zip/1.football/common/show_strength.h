/*************************************************************************
	> File Name: show_strength.h
	> Author: yanzhiwei
	> Mail: 1931248856@qq.com
	> Created Time: 2021年03月25日 星期四 20时45分18秒
 ************************************************************************/

#ifndef _SHOW_STRENGTH_H
#define _SHOW_STRENGTH_H
void stop_ball();
void kick_ball();
void carry_ball();
void show_strength();
#endif
