/*************************************************************************
	> File Name: show_data_stream.h
	> Author: yanzhiwei
	> Mail: 1931248856@qq.com
	> Created Time: 2021年03月25日 星期四 20时42分40秒
 ************************************************************************/

#ifndef _SHOW_DATA_STREAM_H
#define _SHOW_DATA_STREAM_H
void show_data_stream(int type);
#endif
