/*************************************************************************
	> File Name: client_recver.h
	> Author: yanzhiwei
	> Mail: 1931248856@qq.com
	> Created Time: 2021年03月25日 星期四 21时17分47秒
 ************************************************************************/

#ifndef _CLIENT_RECVER_H
#define _CLIENT_RECVER_H
void *client_recv(void *arg);
#endif
