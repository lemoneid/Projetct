/*************************************************************************
	> File Name: tcp_socket.h
	> Author: yanzhiwei
	> Mail: 1931248856@qq.com
	> Created Time: 2021年03月25日 星期四 09时25分38秒
 ************************************************************************/

#ifndef _TCP_SOCKET_H
#define _TCP_SOCKET_H
int socket_connect(char *ip, int port);
int socket_create(int port);
#endif
