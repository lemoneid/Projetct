/*************************************************************************
	> File Name: udp_client.h
	> Author: yanzhiwei
	> Mail: 1931248856@qq.com
	> Created Time: 2021年03月26日 星期五 21时11分40秒
 ************************************************************************/

#ifndef _UDP_CLIENT_H
#define _UDP_CLIENT_H
int socket_udp();
#endif
