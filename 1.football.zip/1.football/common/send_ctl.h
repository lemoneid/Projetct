/*************************************************************************
	> File Name: send_ctl.h
	> Author: yanzhiwei
	> Mail: 1931248856@qq.com
	> Created Time: 2021年03月25日 星期四 20时03分31秒
 ************************************************************************/

#ifndef _SEND_CTL_H
#define _SEND_CTL_H
void send_ctl();
#endif
