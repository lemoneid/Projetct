/*************************************************************************
	> File Name: ball_status.h
	> Author: yanzhiwei
	> Mail: 1931248856@qq.com
	> Created Time: 2021年03月25日 星期四 19时51分51秒
 ************************************************************************/

#ifndef _BALL_STATUS_H
#define _BALL_STATUS_H

int can_access(struct Point *loc);
int can_kick(struct Point *loc, int strength);

#endif
