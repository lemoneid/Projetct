/*************************************************************************
	> File Name: udp_server.h
	> Author: yanzhiwei
	> Mail: 1931248856@qq.com
	> Created Time: 2021年03月26日 星期五 21时19分30秒
 ************************************************************************/

#ifndef _UDP_SERVER_H
#define _UDP_SERVER_H
int socket_create_udp(int port);
#endif
