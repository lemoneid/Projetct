/*************************************************************************
	> File Name: client_re_drew.h
	> Author: yanzhiwei
	> Mail: 1931248856@qq.com
	> Created Time: 2021年03月25日 星期四 21时29分53秒
 ************************************************************************/

#ifndef _CLIENT_RE_DREW_H
#define _CLIENT_RE_DREW_H
#include "cJSON.h"
void re_drew(cJSON *root);
void re_drew_player(cJSON *users);
#endif
